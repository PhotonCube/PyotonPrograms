﻿$oswin = [Window]::new(85 * 2, 50 * 2, "Button")

$button = New-Object System.Windows.Forms.Button
$button.Width = 85
$button.Height = 50
$button.Text = "Click me!"
$button.Left = 42
$button.Top = 55
$oswin.Controls.Add($button)