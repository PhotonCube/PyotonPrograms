﻿$script:oswin = [Window]::new(500, 500, "Notepad")

$entry = New-Object System.Windows.Forms.TextBox
$entry.Width = 480
$entry.Height = 450
$entry.Multiline = $true
$entry.ScrollBars = "Both"
$entry.AcceptsReturn = $true
$entry.AcceptsTab = $true
$entry.Font = New-Object System.Drawing.Font("Consolas", 12)
$entry.Left = 10
$entry.Top = 70
$oswin.Controls.Add($entry)

$save = New-Object System.Windows.Forms.Button
$save.Width = 50
$save.Height = 30
$save.Text = "Save"
$save.Left = 10
$save.Top = 35
$save | Add-Member entry $entry
$oswin.Controls.Add($save)

$save.Add_MouseClick({
    $promptwindow = [Window]::new(300, 120, "Enter file name")
    $promptwindow.BringToFront()

    $fileentry = New-Object System.Windows.Forms.TextBox
    $fileentry.Width = 260
    $fileentry.Left = 10
    $fileentry.Top = 40

    $fileentry | Add-Member entry $this.entry

    $promptwindow.Controls.Add($fileentry)

    $fileentry.Add_KeyDown({
        param($s, $e)
        $key = $e.KeyCode.ToString()

        if ($key -eq "Return") {
            $path = "$dir\Files\$($this.Text).txt"
            Set-Content $path $this.entry.Text
            $this.Parent.Close()
        }
    })
})


$open = New-Object System.Windows.Forms.Button
$open.Width = 50
$open.Height = 30
$open.Text = "Open"
$open.Left = 70
$open.Top = 35
$open | Add-Member entry $entry
$oswin.Controls.Add($open)

$open.Add_MouseClick({
    $promptwindow = [Window]::new(300, 120, "Enter file name")
    $promptwindow.BringToFront()

    $fileentry = New-Object System.Windows.Forms.TextBox
    $fileentry.Width = 260
    $fileentry.Left = 10
    $fileentry.Top = 40
    $fileentry | Add-Member open $this
    $promptwindow.Controls.Add($fileentry)

    $fileentry.Add_KeyDown({
        param($s, $e)
        $key = $e.KeyCode.ToString()

        if ($key -eq "Return") {
            $path = "$dir\Files\$($this.Text).txt"

            if (Test-Path $path) {
                $this.open.entry.Text = Get-Content $path -Raw
                $this.Parent.Close()
            }
        }
    })
})
