﻿$taskbar = New-Object System.Windows.Forms.Panel
$taskbar.Height = 60
$taskbar.BackColor = [System.Drawing.Color]::DarkGray
$window.Controls.Add($taskbar)

$exitbutton = New-Object System.Windows.Forms.Button
$exitbutton.Width = 60
$exitbutton.Height = 30
$exitbutton.BackColor = [System.Drawing.Color]::Red
$exitbutton.ForeColor = [System.Drawing.Color]::White
$exitbutton.Text = "Exit"
$exitbutton.Font = New-Object System.Drawing.Font($exitbutton.Font.FontFamily, 16)
$exitbutton.Top = 15
$taskbar.Controls.Add($exitbutton)

$exitbutton.Add_MouseClick({
    $window.Close()
})

$window.Add_Shown({
    $taskbar.Width = $window.Width
    $taskbar.Top = $window.Height - 60

    $exitbutton.Left = $taskbar.Width - 75
})