﻿$script:oswin = [Window]::new(300, 200, "Run")

$message = New-Object System.Windows.Forms.Label
$message.Text = "Type in any program to run"
$message.Font = New-Object System.Drawing.Font($message.Font.FontFamily, 16)
$message.Left = 10
$message.Top = 40
$message.AutoSize = $true
$oswin.Controls.Add($message)

$textbox = New-Object System.Windows.Forms.TextBox
$textbox.Width = 270
$textbox.Left = 10
$textbox.Top = 50 + $message.Height
$oswin.Controls.Add($textbox)

$textbox.Add_KeyDown({
    param($s, $e)
    $key = $e.KeyCode.ToString()

    if ($key -eq "Return") {
        try { .  "$dir\Applications\$($this.Text)\main.ps1" }
        catch { try { . "$dir\System\$($this.Text)" } catch {}}
        $this.Parent.Close()
    }
})