﻿$window = New-Object System.Windows.Forms.Form
$window.BackColor = [System.Drawing.Color]::Teal
$window.Text = "PyotoOS v1.0"
$window.FormBorderStyle = "None"
$window.WindowState = "Maximized"
$window.TopMost = $true
$window.KeyPreview = $true

class Window : System.Windows.Forms.Panel {
    [System.Windows.Forms.Panel] $banner
    [System.Windows.Forms.Label] $title
    [System.Windows.Forms.Button] $closebutton

    [bool] $dragging
    [System.Drawing.Point] $crp

    Window([int] $width, [int] $height, [string] $title) {
        $this.Width = $width
        $this.Height = $height + 30
        $this.BackColor = [System.Drawing.Color]::DarkGray
        $script:window.Controls.Add($this)

        $this.banner = New-Object System.Windows.Forms.Panel
        $this.banner.Width = $width
        $this.banner.Height = 30
        $this.banner.BackColor = [System.Drawing.Color]::Black
        $this.Controls.Add($this.banner)

        $this.title = New-Object System.Windows.Forms.Label
        $this.title.ForeColor = [System.Drawing.Color]::White
        $this.title.Text = $title
        $this.title.Font = New-Object System.Drawing.Font($this.title.Font.FontFamily, 16)
        $this.title.Enabled = $false
        $this.banner.Controls.Add($this.title)

        $this.closebutton = New-Object System.Windows.Forms.Button
        $this.closebutton.Width = 20
        $this.closebutton.Height = 20
        $this.closebutton.BackColor = [System.Drawing.Color]::Red
        $this.closebutton.ForeColor = [System.Drawing.Color]::White
        $this.closebutton.Text = "X"
        $this.closebutton.Left = $width - 25
        $this.closebutton.Top = 5
        $this.banner.Controls.Add($this.closebutton)

        $this.closebutton.Add_MouseClick({
            $this.Parent.Parent.Close()
        })

        $this.banner.Add_MouseDown({
            param($s, $e)
            $this.Parent.dragging = $true
            $this.Parent.crp = $e.Location
            $this.Parent.BringToFront()
        })

        $this.banner.Add_MouseUp({
            $this.Parent.dragging = $false
        })

        $this.banner.Add_MouseMove({
            param($s, $e)
            if (-not $this.Parent.dragging) { return }

            $dx = $e.X - $this.Parent.crp.X
            $dy = $e.Y - $this.Parent.crp.Y

            $this.Parent.Left += $dx
            $this.Parent.Top += $dy
        })
    }

    Close() {
        $script:window.Controls.Remove($this)
    }
}

$window.Add_KeyDown({
    param($s, $e)
    $key = $e.KeyCode.ToString()

    if ($key -eq "F12"){
        . "$dir\System\Run.ps1"
    }
})

. "$dir\System\Taskbar.ps1"

$window.ShowDialog()